#ifndef EMPTY_H
#define EMPTY_H

namespace ns3 {
/**
 * \brief make Callback use a separate empty type
 */
class empty {};
}

#endif /* EMPTY_H */
